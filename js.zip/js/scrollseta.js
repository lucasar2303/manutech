var mybutton = document.getElementById("seta");

function topFunction() {
	var height = screen.height;
	console.log(height);

	  window.scroll(0,height-200);

}